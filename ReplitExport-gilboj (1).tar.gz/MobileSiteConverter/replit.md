# EasyMed Healthcare Management System

## Overview

EasyMed is a comprehensive healthcare management platform designed to simplify medical administration for both patients and healthcare providers. The system provides a mobile-first experience with features for appointment scheduling, prescription management, health record tracking, and emergency services access.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite for build tooling
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack React Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation
- **Mobile-First Design**: Responsive layout optimized for mobile devices

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless PostgreSQL
- **API Design**: RESTful endpoints with JSON responses
- **Development Server**: Vite development server with HMR support

### Build System
- **Frontend**: Vite with React plugin and TypeScript support
- **Backend**: ESBuild for server bundling
- **Development**: Concurrent development with Vite proxy

## Key Components

### Database Schema
- **Users**: User profiles with personal and emergency contact information
- **Appointments**: Scheduled medical visits with doctor, specialty, and status tracking
- **Prescriptions**: Medication management with dosage, frequency, and refill tracking
- **Health Records**: Medical history including lab results, diagnoses, vital signs, and immunizations

### API Endpoints
- **Appointments**: CRUD operations for appointment management
- **Prescriptions**: Medication tracking and refill requests
- **Health Records**: Medical history retrieval and management
- **User Profile**: Personal information management

### User Interface Components
- **Mobile Header**: Branded header with navigation controls
- **Bottom Navigation**: Tab-based navigation for primary app sections
- **Form Components**: Reusable form elements with validation
- **Card Components**: Structured data display for appointments, prescriptions, and records
- **Healthcare-Specific Components**: Specialized UI for medical data presentation

## Data Flow

1. **User Interaction**: Mobile-optimized interface captures user input
2. **Form Validation**: Client-side validation using Zod schemas
3. **API Communication**: TanStack Query manages HTTP requests to Express server
4. **Database Operations**: Drizzle ORM handles PostgreSQL database interactions
5. **Real-time Updates**: Query invalidation ensures UI reflects latest data
6. **Error Handling**: Comprehensive error handling with user-friendly messages

## External Dependencies

### UI and Styling
- **Radix UI**: Accessible headless components for complex UI elements
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Lucide React**: Icon library for consistent iconography
- **Class Variance Authority**: Type-safe component variants

### Development Tools
- **TypeScript**: Type safety and enhanced developer experience
- **ESLint/Prettier**: Code quality and formatting
- **Vite Plugins**: Development optimizations and error handling

### Database and Backend
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **Drizzle Kit**: Database migration and schema management
- **Express Middleware**: Request logging and error handling

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with Express backend
- **Hot Module Replacement**: Instant updates during development
- **Database**: Neon serverless PostgreSQL for development

### Production Build
- **Frontend**: Static asset generation with Vite
- **Backend**: Single file bundle with ESBuild
- **Database**: Production PostgreSQL instance via Neon
- **Deployment**: Node.js production server serving static files and API

### Environment Configuration
- **Database URL**: Configured via environment variables
- **Development Mode**: Conditional feature loading
- **Error Handling**: Production-ready error responses

## User Preferences

Preferred communication style: Simple, everyday language.
Target Market: India-focused healthcare application with local contact numbers, addresses, and cultural context.

## PWA Capabilities

### Progressive Web App Features
- **Installable**: Users can install EasyMed on their devices like a native app
- **Offline Ready**: Service worker provides basic offline functionality
- **App-like Experience**: Standalone display mode removes browser UI
- **Quick Access**: Installed app appears on home screen with custom icon

### Installation Instructions
1. **Android/Chrome**: Visit the site, tap "Install" when prompted, or use browser menu "Add to Home Screen"
2. **iOS/Safari**: Visit the site, tap Share button, select "Add to Home Screen"
3. **Desktop**: Look for install icon in address bar or use browser menu

### For App Store Deployment
Current app is PWA-ready. To deploy to app stores:
1. **Google Play**: Use TWA (Trusted Web Activities) or Capacitor
2. **Apple App Store**: Use Capacitor to create native iOS wrapper
3. **Alternative**: Deploy PWA and guide users to install directly

## Changelog

Changelog:
- July 02, 2025. Initial setup and Indian localization
- July 02, 2025. Added PWA capabilities with service worker and install prompt