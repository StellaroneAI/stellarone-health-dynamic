import { 
  users, appointments, prescriptions, healthRecords,
  type User, type InsertUser,
  type Appointment, type InsertAppointment,
  type Prescription, type InsertPrescription,
  type HealthRecord, type InsertHealthRecord
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Appointment operations
  getAppointments(userId: number): Promise<Appointment[]>;
  getAppointment(id: number): Promise<Appointment | undefined>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointment: Partial<Appointment>): Promise<Appointment | undefined>;
  
  // Prescription operations
  getPrescriptions(userId: number): Promise<Prescription[]>;
  getPrescription(id: number): Promise<Prescription | undefined>;
  createPrescription(prescription: InsertPrescription): Promise<Prescription>;
  updatePrescription(id: number, prescription: Partial<Prescription>): Promise<Prescription | undefined>;
  
  // Health record operations
  getHealthRecords(userId: number): Promise<HealthRecord[]>;
  getHealthRecord(id: number): Promise<HealthRecord | undefined>;
  createHealthRecord(record: InsertHealthRecord): Promise<HealthRecord>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private appointments: Map<number, Appointment>;
  private prescriptions: Map<number, Prescription>;
  private healthRecords: Map<number, HealthRecord>;
  private currentUserId: number;
  private currentAppointmentId: number;
  private currentPrescriptionId: number;
  private currentHealthRecordId: number;

  constructor() {
    this.users = new Map();
    this.appointments = new Map();
    this.prescriptions = new Map();
    this.healthRecords = new Map();
    this.currentUserId = 1;
    this.currentAppointmentId = 1;
    this.currentPrescriptionId = 1;
    this.currentHealthRecordId = 1;

    // Create a demo user
    this.createUser({
      username: "patient1",
      password: "password123",
      firstName: "Arjun",
      lastName: "Sharma",
      email: "arjun.sharma@gmail.com",
      phone: "+91 98765 43210",
      dateOfBirth: "1985-06-15",
      address: "A-123, Sector 15, Noida, Uttar Pradesh 201301",
      emergencyContact: "Priya Sharma",
      emergencyPhone: "+91 87654 32109",
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      firstName: insertUser.firstName || null,
      lastName: insertUser.lastName || null,
      email: insertUser.email || null,
      phone: insertUser.phone || null,
      dateOfBirth: insertUser.dateOfBirth || null,
      address: insertUser.address || null,
      emergencyContact: insertUser.emergencyContact || null,
      emergencyPhone: insertUser.emergencyPhone || null
    };
    this.users.set(id, user);
    
    // Add some sample appointments for demo
    if (id === 1) {
      this.createAppointment({
        userId: id,
        doctorName: "Dr. Priya Sharma",
        specialty: "General Medicine",
        date: "2024-12-08",
        time: "10:30",
        reason: "Regular health checkup",
        status: "scheduled",
        notes: "Annual physical examination"
      });
      
      this.createAppointment({
        userId: id,
        doctorName: "Dr. Raj Malhotra",
        specialty: "Cardiology",
        date: "2024-12-15",
        time: "14:00",
        reason: "Heart monitoring",
        status: "scheduled",
        notes: "Follow-up for blood pressure"
      });

      // Add sample prescriptions
      this.createPrescription({
        userId: id,
        medicationName: "Paracetamol",
        dosage: "500mg",
        frequency: "Twice daily",
        prescribedBy: "Dr. Priya Sharma",
        prescribedDate: "2024-11-20",
        refillsRemaining: 2,
        instructions: "Take with food",
        status: "active"
      });

      this.createPrescription({
        userId: id,
        medicationName: "Crocin",
        dosage: "650mg",
        frequency: "As needed",
        prescribedBy: "Dr. Raj Malhotra",
        prescribedDate: "2024-11-15",
        refillsRemaining: 1,
        instructions: "For fever and pain relief",
        status: "active"
      });

      // Add sample health records
      this.createHealthRecord({
        userId: id,
        recordType: "lab_result",
        title: "Blood Sugar Test",
        description: "Fasting blood glucose level",
        value: "95",
        unit: "mg/dL",
        date: "2024-11-25",
        provider: "Apollo Diagnostics",
        category: "Diabetes Screening"
      });

      this.createHealthRecord({
        userId: id,
        recordType: "vital_signs",
        title: "Blood Pressure Check",
        description: "Regular BP monitoring",
        value: "120/80",
        unit: "mmHg",
        date: "2024-11-20",
        provider: "Max Healthcare",
        category: "Routine Checkup"
      });

      this.createHealthRecord({
        userId: id,
        recordType: "immunization",
        title: "COVID-19 Vaccination",
        description: "Covishield vaccine - 2nd dose",
        date: "2024-06-15",
        provider: "Government Health Center",
        category: "Vaccination"
      });
    }
    
    return user;
  }

  // Appointment operations
  async getAppointments(userId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      (appointment) => appointment.userId === userId,
    );
  }

  async getAppointment(id: number): Promise<Appointment | undefined> {
    return this.appointments.get(id);
  }

  async createAppointment(insertAppointment: InsertAppointment): Promise<Appointment> {
    const id = this.currentAppointmentId++;
    const appointment: Appointment = { 
      ...insertAppointment, 
      id,
      status: insertAppointment.status || "scheduled",
      notes: insertAppointment.notes || null,
      createdAt: new Date()
    };
    this.appointments.set(id, appointment);
    return appointment;
  }

  async updateAppointment(id: number, update: Partial<Appointment>): Promise<Appointment | undefined> {
    const appointment = this.appointments.get(id);
    if (!appointment) return undefined;
    
    const updated = { ...appointment, ...update };
    this.appointments.set(id, updated);
    return updated;
  }

  // Prescription operations
  async getPrescriptions(userId: number): Promise<Prescription[]> {
    return Array.from(this.prescriptions.values()).filter(
      (prescription) => prescription.userId === userId,
    );
  }

  async getPrescription(id: number): Promise<Prescription | undefined> {
    return this.prescriptions.get(id);
  }

  async createPrescription(insertPrescription: InsertPrescription): Promise<Prescription> {
    const id = this.currentPrescriptionId++;
    const prescription: Prescription = { 
      ...insertPrescription, 
      id,
      status: insertPrescription.status || "active",
      refillsRemaining: insertPrescription.refillsRemaining || 0,
      instructions: insertPrescription.instructions || null,
      createdAt: new Date()
    };
    this.prescriptions.set(id, prescription);
    return prescription;
  }

  async updatePrescription(id: number, update: Partial<Prescription>): Promise<Prescription | undefined> {
    const prescription = this.prescriptions.get(id);
    if (!prescription) return undefined;
    
    const updated = { ...prescription, ...update };
    this.prescriptions.set(id, updated);
    return updated;
  }

  // Health record operations
  async getHealthRecords(userId: number): Promise<HealthRecord[]> {
    return Array.from(this.healthRecords.values()).filter(
      (record) => record.userId === userId,
    );
  }

  async getHealthRecord(id: number): Promise<HealthRecord | undefined> {
    return this.healthRecords.get(id);
  }

  async createHealthRecord(insertRecord: InsertHealthRecord): Promise<HealthRecord> {
    const id = this.currentHealthRecordId++;
    const record: HealthRecord = { 
      ...insertRecord, 
      id,
      value: insertRecord.value || null,
      description: insertRecord.description || null,
      unit: insertRecord.unit || null,
      provider: insertRecord.provider || null,
      category: insertRecord.category || null,
      createdAt: new Date()
    };
    this.healthRecords.set(id, record);
    return record;
  }
}

export const storage = new MemStorage();
