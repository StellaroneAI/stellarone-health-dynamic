import { Calendar, Phone, Pill, FileText } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import MobileHeader from "@/components/mobile-header";
import BottomNavigation from "@/components/bottom-navigation";

const quickActions = [
  {
    title: "Book Appointment",
    subtitle: "Schedule your visit",
    href: "/book-appointment",
    icon: Calendar,
    color: "bg-blue-100 text-healthcare-blue",
  },
  {
    title: "Emergency",
    subtitle: "24/7 urgent care",
    href: "/emergency",
    icon: Phone,
    color: "bg-red-100 text-healthcare-red",
  },
  {
    title: "Prescriptions",
    subtitle: "Refill medications",
    href: "/prescriptions",
    icon: Pill,
    color: "bg-green-100 text-healthcare-green",
  },
  {
    title: "Records",
    subtitle: "View health data",
    href: "/records",
    icon: FileText,
    color: "bg-purple-100 text-healthcare-purple",
  },
];

const healthTips = [
  {
    title: "Regular Checkups",
    subtitle: "Schedule annual health screenings",
    image: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
    bgColor: "bg-blue-50",
  },
  {
    title: "Healthy Diet",
    subtitle: "Maintain balanced nutrition daily",
    image: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
    bgColor: "bg-green-50",
  },
  {
    title: "Stay Active",
    subtitle: "Exercise regularly for wellness",
    image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80",
    bgColor: "bg-purple-50",
  },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <MobileHeader />
      
      {/* Welcome Hero Section */}
      <section className="hero-gradient px-4 py-8 text-white">
        <div className="max-w-md mx-auto text-center">
          <h2 className="text-2xl font-bold mb-2">Welcome to EasyMed</h2>
          <p className="text-purple-100 mb-6 text-sm leading-relaxed">Your health, simplified and accessible</p>
          
          <div className="mb-6 rounded-2xl overflow-hidden shadow-lg">
            <img 
              src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400" 
              alt="Medical professionals team" 
              className="w-full h-32 object-cover" 
            />
          </div>
          
          <Link href="/book-appointment">
            <Button className="w-full bg-white text-primary font-semibold py-3 px-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-200">
              Book Appointment
            </Button>
          </Link>
        </div>
      </section>
      
      {/* Quick Actions */}
      <section className="px-4 py-6 -mt-4 relative z-10">
        <div className="max-w-md mx-auto">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Quick Actions</h3>
          
          <div className="grid grid-cols-2 gap-4">
            {quickActions.map((action) => (
              <Link key={action.href} href={action.href}>
                <Card className="card-hover cursor-pointer">
                  <CardContent className="p-4">
                    <div className={`w-12 h-12 ${action.color} rounded-lg flex items-center justify-center mb-3`}>
                      <action.icon className="w-6 h-6" />
                    </div>
                    <h4 className="font-semibold text-gray-800 text-sm">{action.title}</h4>
                    <p className="text-xs text-gray-500 mt-1">{action.subtitle}</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>
      
      {/* Statistics Section */}
      <section className="px-4 py-6">
        <div className="max-w-md mx-auto">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 text-center">EasyMed at a Glance</h3>
          
          <div className="mb-6 rounded-2xl overflow-hidden shadow-lg">
            <img 
              src="https://images.unsplash.com/photo-1551190822-a9333d879b1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=300" 
              alt="Modern hospital facility" 
              className="w-full h-40 object-cover" 
            />
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-primary">15+</div>
                <div className="text-xs text-gray-500 font-medium">Years Serving</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold healthcare-blue">150+</div>
                <div className="text-xs text-gray-500 font-medium">Expert Doctors</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold healthcare-green">5L+</div>
                <div className="text-xs text-gray-500 font-medium">Patients Helped</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
      
      {/* Health Tips Section */}
      <section className="px-4 py-6 bg-white">
        <div className="max-w-md mx-auto">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Health Tips & Resources</h3>
          
          <div className="space-y-4">
            {healthTips.map((tip, index) => (
              <div key={index} className={`flex items-center space-x-3 p-4 ${tip.bgColor} rounded-xl`}>
                <img 
                  src={tip.image} 
                  alt={tip.title} 
                  className="w-12 h-12 rounded-lg object-cover" 
                />
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-800 text-sm">{tip.title}</h4>
                  <p className="text-xs text-gray-600 mt-1">{tip.subtitle}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Spacer for bottom navigation */}
      <div className="h-20"></div>
      
      <BottomNavigation />
    </div>
  );
}
