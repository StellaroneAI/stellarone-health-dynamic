import { Phone, MapPin, Clock, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import MobileHeader from "@/components/mobile-header";
import BottomNavigation from "@/components/bottom-navigation";

const emergencyContacts = [
  {
    title: "Emergency Services",
    number: "108",
    description: "Life-threatening emergencies",
    color: "bg-red-500 hover:bg-red-600",
    priority: "Critical",
  },
  {
    title: "EasyMed Emergency",
    number: "+91 98765 00000",
    description: "24/7 medical emergency line",
    color: "bg-orange-500 hover:bg-orange-600",
    priority: "Urgent",
  },
  {
    title: "Medical Helpline",
    number: "+91 80801 99000",
    description: "Medical advice and guidance",
    color: "bg-blue-500 hover:bg-blue-600",
    priority: "Non-urgent",
  },
];

const nearbyFacilities = [
  {
    name: "All India Institute of Medical Sciences",
    address: "Ansari Nagar, New Delhi 110029",
    distance: "1.2 km",
    waitTime: "20 min",
    type: "Government Hospital",
  },
  {
    name: "Max Super Speciality Hospital",
    address: "Saket, New Delhi 110017",
    distance: "2.5 km",
    waitTime: "15 min",
    type: "Private Hospital",
  },
  {
    name: "Apollo Emergency Care",
    address: "Sector 26, Noida 201301",
    distance: "3.1 km",
    waitTime: "10 min",
    type: "Emergency Center",
  },
];

const symptoms = [
  "Chest pain or pressure",
  "Difficulty breathing",
  "Severe bleeding",
  "Loss of consciousness",
  "Severe allergic reaction",
  "Stroke symptoms",
  "Severe burns",
  "Poisoning",
];

export default function Emergency() {
  const handleCallEmergency = (number: string) => {
    window.location.href = `tel:${number}`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <MobileHeader title="Emergency" subtitle="24/7 urgent care" />
      
      <div className="px-4 py-6 pb-24">
        <div className="max-w-md mx-auto">
          {/* Warning Banner */}
          <Card className="mb-6 border-red-200 bg-red-50">
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-red-900 mb-1">Medical Emergency</h3>
                  <p className="text-sm text-red-700">
                    If you are experiencing a life-threatening emergency, call 108 immediately.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Emergency Contacts */}
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Emergency Contacts</h2>
            <div className="space-y-3">
              {emergencyContacts.map((contact, index) => (
                <Card key={index} className="card-hover cursor-pointer" onClick={() => handleCallEmergency(contact.number)}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className="font-semibold text-gray-900">{contact.title}</h3>
                          <Badge variant="outline" className="text-xs">
                            {contact.priority}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{contact.description}</p>
                        <div className="flex items-center space-x-2">
                          <Phone className="w-4 h-4 text-gray-400" />
                          <span className="text-sm font-medium text-gray-700">{contact.number}</span>
                        </div>
                      </div>
                      <Button className={`${contact.color} text-white`} size="sm">
                        Call
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Nearby Facilities */}
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Nearby Emergency Facilities</h2>
            <div className="space-y-3">
              {nearbyFacilities.map((facility, index) => (
                <Card key={index} className="card-hover">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold text-gray-900">{facility.name}</h3>
                      <Badge variant="secondary" className="text-xs">
                        {facility.type}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2 text-sm text-gray-600">
                        <MapPin className="w-4 h-4" />
                        <span>{facility.address}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-2 text-gray-600">
                          <span>Distance: {facility.distance}</span>
                        </div>
                        <div className="flex items-center space-x-2 text-green-600">
                          <Clock className="w-4 h-4" />
                          <span>Wait: {facility.waitTime}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* When to Call 911 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center space-x-2">
                <AlertTriangle className="w-5 h-5 text-red-500" />
                <span>When to Call 108</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-3">
                Call emergency services immediately if you experience any of these symptoms:
              </p>
              <div className="grid grid-cols-1 gap-2">
                {symptoms.map((symptom, index) => (
                  <div key={index} className="flex items-center space-x-2 text-sm">
                    <div className="w-2 h-2 bg-red-500 rounded-full flex-shrink-0"></div>
                    <span className="text-gray-700">{symptom}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
}
