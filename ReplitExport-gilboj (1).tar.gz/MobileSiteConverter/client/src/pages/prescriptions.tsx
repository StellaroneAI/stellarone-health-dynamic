import { Pill, Plus, Search } from "lucide-react";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import MobileHeader from "@/components/mobile-header";
import BottomNavigation from "@/components/bottom-navigation";
import PrescriptionCard from "@/components/prescription-card";
import { apiRequest } from "@/lib/queryClient";
import type { Prescription } from "@shared/schema";

export default function Prescriptions() {
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: prescriptions, isLoading } = useQuery<Prescription[]>({
    queryKey: ["/api/prescriptions"],
  });

  const refillMutation = useMutation({
    mutationFn: async (prescriptionId: number) => {
      const prescription = prescriptions?.find(p => p.id === prescriptionId);
      if (!prescription) throw new Error("Prescription not found");
      
      return await apiRequest("PATCH", `/api/prescriptions/${prescriptionId}`, {
        refillsRemaining: Math.max(0, prescription.refillsRemaining - 1),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prescriptions"] });
      toast({
        title: "Refill Requested",
        description: "Your prescription refill has been requested successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to request refill. Please try again.",
        variant: "destructive",
      });
    },
  });

  const filteredPrescriptions = prescriptions?.filter((prescription) =>
    prescription.medicationName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    prescription.prescribedBy.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleRefill = (prescriptionId: number) => {
    refillMutation.mutate(prescriptionId);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <MobileHeader title="Prescriptions" subtitle="Manage medications" />
        <div className="px-4 py-6 pb-24">
          <div className="max-w-md mx-auto space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <Skeleton className="h-3 w-1/2 mb-2" />
                  <Skeleton className="h-3 w-2/3" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        <BottomNavigation />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <MobileHeader title="Prescriptions" subtitle="Manage medications" />
      
      <div className="px-4 py-6 pb-24">
        <div className="max-w-md mx-auto">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-xl font-semibold text-gray-900">Your Prescriptions</h1>
            <Button size="sm" variant="outline">
              <Plus className="w-4 h-4 mr-1" />
              Add
            </Button>
          </div>

          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search medications..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {!filteredPrescriptions || filteredPrescriptions.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Pill className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  {searchTerm ? "No prescriptions found" : "No prescriptions yet"}
                </h3>
                <p className="text-gray-500 mb-4">
                  {searchTerm
                    ? "Try adjusting your search terms"
                    : "Your prescribed medications will appear here"}
                </p>
                {!searchTerm && (
                  <Button variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Prescription
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredPrescriptions.map((prescription) => (
                <PrescriptionCard
                  key={prescription.id}
                  prescription={prescription}
                  onRefill={handleRefill}
                />
              ))}
            </div>
          )}
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
}
