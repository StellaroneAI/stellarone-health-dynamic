import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import MobileHeader from "@/components/mobile-header";
import BottomNavigation from "@/components/bottom-navigation";
import AppointmentForm from "@/components/appointment-form";

export default function BookAppointment() {
  return (
    <div className="min-h-screen bg-gray-50">
      <MobileHeader title="Book Appointment" subtitle="Schedule your visit" />
      
      <div className="px-4 py-6 pb-24">
        <div className="max-w-md mx-auto">
          <div className="flex items-center space-x-3 mb-6">
            <Link href="/">
              <Button variant="ghost" size="sm" className="p-2">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-xl font-semibold text-gray-900">Schedule Appointment</h1>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Appointment Details</CardTitle>
            </CardHeader>
            <CardContent>
              <AppointmentForm />
            </CardContent>
          </Card>
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
}
