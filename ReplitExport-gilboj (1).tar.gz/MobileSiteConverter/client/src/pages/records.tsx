import { FileText, Plus, Search, Filter } from "lucide-react";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import MobileHeader from "@/components/mobile-header";
import BottomNavigation from "@/components/bottom-navigation";
import HealthRecordCard from "@/components/health-record-card";
import type { HealthRecord } from "@shared/schema";

const recordTypeOptions = [
  { value: "all", label: "All Records" },
  { value: "lab_result", label: "Lab Results" },
  { value: "diagnosis", label: "Diagnoses" },
  { value: "vital_signs", label: "Vital Signs" },
  { value: "immunization", label: "Immunizations" },
];

export default function Records() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedType, setSelectedType] = useState("all");

  const { data: records, isLoading } = useQuery<HealthRecord[]>({
    queryKey: ["/api/health-records"],
  });

  const filteredRecords = records?.filter((record) => {
    const matchesSearch = 
      record.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.provider?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = selectedType === "all" || record.recordType === selectedType;
    
    return matchesSearch && matchesType;
  });

  // Sort records by date (newest first)
  const sortedRecords = filteredRecords?.sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <MobileHeader title="Health Records" subtitle="Your medical history" />
        <div className="px-4 py-6 pb-24">
          <div className="max-w-md mx-auto space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <Skeleton className="h-3 w-1/2 mb-2" />
                  <Skeleton className="h-3 w-2/3" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        <BottomNavigation />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <MobileHeader title="Health Records" subtitle="Your medical history" />
      
      <div className="px-4 py-6 pb-24">
        <div className="max-w-md mx-auto">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-xl font-semibold text-gray-900">Health Records</h1>
            <Button size="sm" variant="outline">
              <Plus className="w-4 h-4 mr-1" />
              Add
            </Button>
          </div>

          {/* Search and Filter */}
          <div className="space-y-4 mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search records..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                {recordTypeOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {!sortedRecords || sortedRecords.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  {searchTerm || selectedType !== "all" ? "No records found" : "No health records yet"}
                </h3>
                <p className="text-gray-500 mb-4">
                  {searchTerm || selectedType !== "all"
                    ? "Try adjusting your search or filter"
                    : "Your medical records and test results will appear here"}
                </p>
                {!searchTerm && selectedType === "all" && (
                  <Button variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Record
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {sortedRecords.map((record) => (
                <HealthRecordCard key={record.id} record={record} />
              ))}
            </div>
          )}
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
}
