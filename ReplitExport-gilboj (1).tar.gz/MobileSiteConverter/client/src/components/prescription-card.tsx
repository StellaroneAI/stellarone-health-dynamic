import { Pill, Clock, AlertCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { Prescription } from "@shared/schema";

interface PrescriptionCardProps {
  prescription: Prescription;
  onRefill?: (id: number) => void;
}

export default function PrescriptionCard({ prescription, onRefill }: PrescriptionCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "expired":
        return "bg-red-100 text-red-800";
      case "discontinued":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  return (
    <Card className="card-hover">
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-3">
          <div className="flex items-start space-x-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <Pill className="w-5 h-5 text-green-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900">{prescription.medicationName}</h3>
              <p className="text-sm text-gray-600">{prescription.dosage}</p>
            </div>
          </div>
          <Badge className={getStatusColor(prescription.status)}>
            {prescription.status.charAt(0).toUpperCase() + prescription.status.slice(1)}
          </Badge>
        </div>
        
        <div className="space-y-2 mb-3">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Frequency:</span>
            <span className="text-gray-900">{prescription.frequency}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Prescribed by:</span>
            <span className="text-gray-900">{prescription.prescribedBy}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Date:</span>
            <span className="text-gray-900">{formatDate(prescription.prescribedDate)}</span>
          </div>
        </div>

        {prescription.instructions && (
          <div className="mb-3 p-2 bg-blue-50 rounded-lg">
            <p className="text-xs text-blue-700">{prescription.instructions}</p>
          </div>
        )}

        <div className="flex items-center justify-between pt-3 border-t border-gray-100">
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-gray-400" />
            <span className="text-sm text-gray-600">
              {prescription.refillsRemaining} refills remaining
            </span>
          </div>
          
          {prescription.status === "active" && prescription.refillsRemaining > 0 && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => onRefill?.(prescription.id)}
            >
              Refill
            </Button>
          )}
          
          {prescription.refillsRemaining === 0 && prescription.status === "active" && (
            <div className="flex items-center space-x-1 text-orange-600">
              <AlertCircle className="w-4 h-4" />
              <span className="text-xs">Contact doctor</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
