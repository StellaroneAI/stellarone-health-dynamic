import { FileText, Calendar, User, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { HealthRecord } from "@shared/schema";

interface HealthRecordCardProps {
  record: HealthRecord;
}

const recordTypeIcons = {
  lab_result: TrendingUp,
  diagnosis: FileText,
  vital_signs: TrendingUp,
  immunization: User,
};

const recordTypeColors = {
  lab_result: "bg-blue-100 text-blue-600",
  diagnosis: "bg-orange-100 text-orange-600",
  vital_signs: "bg-green-100 text-green-600",
  immunization: "bg-purple-100 text-purple-600",
};

const recordTypeBadgeColors = {
  lab_result: "bg-blue-100 text-blue-800",
  diagnosis: "bg-orange-100 text-orange-800",
  vital_signs: "bg-green-100 text-green-800",
  immunization: "bg-purple-100 text-purple-800",
};

export default function HealthRecordCard({ record }: HealthRecordCardProps) {
  const IconComponent = recordTypeIcons[record.recordType as keyof typeof recordTypeIcons] || FileText;
  const iconColor = recordTypeColors[record.recordType as keyof typeof recordTypeColors] || "bg-gray-100 text-gray-600";
  const badgeColor = recordTypeBadgeColors[record.recordType as keyof typeof recordTypeBadgeColors] || "bg-gray-100 text-gray-800";

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const formatRecordType = (type: string) => {
    return type.split("_").map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(" ");
  };

  return (
    <Card className="card-hover">
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-3">
          <div className="flex items-start space-x-3">
            <div className={`w-10 h-10 ${iconColor} rounded-lg flex items-center justify-center`}>
              <IconComponent className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900">{record.title}</h3>
              {record.category && (
                <p className="text-sm text-gray-600">{record.category}</p>
              )}
            </div>
          </div>
          <Badge className={badgeColor}>
            {formatRecordType(record.recordType)}
          </Badge>
        </div>
        
        <div className="space-y-2 mb-3">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Calendar className="w-4 h-4" />
            <span>{formatDate(record.date)}</span>
          </div>
          {record.provider && (
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <User className="w-4 h-4" />
              <span>{record.provider}</span>
            </div>
          )}
        </div>

        {record.description && (
          <div className="mb-3">
            <p className="text-sm text-gray-700">{record.description}</p>
          </div>
        )}

        {record.value && (
          <div className="mb-3 p-3 bg-gray-50 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-gray-700">Result:</span>
              <span className="text-sm font-semibold text-gray-900">
                {record.value} {record.unit && record.unit}
              </span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
